# Wildfire Forecasting System — Bảng tổng kết kết quả

| Nhóm kết quả | Vai trò | Quyết định |
|---|---|---|
| Phase A (dữ liệu thật) | Bằng chứng chính | Ưu tiên — kết quả gốc từ v8.6 Phase A |
| Đánh giá không gian (Bắc→Nam) | Kiểm tra khái quát hóa | Giữ — phát hiện chính của đề tài |
| MODIS–VIIRS | Phân tích bất đồng nguồn nhãn | Giữ, giải thích thận trọng |
| V10/V11 synthetic (spatial, horizon, calibration) | Thử nghiệm bổ sung | Không thay thế bằng chứng thực |
| Environmental ablation synthetic | Thử nghiệm thăm dò | Không đưa vào kết luận chính |
| Website | Sản phẩm trình diễn | Hoàn thiện sau khi khóa mô hình |

## Kết quả chính (Phase A — dữ liệu thật)
- AUROC IID (MODIS): 0,9467
- AUROC IID (VIIRS): 0,8426 ± 0,0006
- AUROC Bắc→Nam (VIIRS): 0,5838 ± 0,0019
- Horizon t+1→t+7: giảm ≈0,02 (1 seed, chưa có std)
- Moran's I: 0,186 ± 0,215 (std > mean, cần permutation test)
- Case-control 1:1: AUROC không đổi (phù hợp tính chất AUROC)
- +lat/lon continuous: 0,5819→0,8113
- +10 lat bins: 0,5596 (không phục hồi)
- Jaccard MODIS/VIIRS: ≈0,106

## Kết quả synthetic (verified_v11 — cùng panel, cùng split)
- Weather only: 0,6868
- +lat/lon: 0,6771 (không phục hồi trên synthetic)
- +land cover: 0,8047 (phục hồi — gợi ý, chưa chứng minh trên data thật)

## Câu hỏi nghiên cứu chính
"Mô hình học máy dự báo nguy cơ cháy từ dữ liệu khí tượng tại Việt Nam
tổng quát hóa như thế nào khi được đánh giá trên vùng địa lý khác với vùng huấn luyện?"

## Giới hạn đã công khai
1. Chưa có NDVI, lớp phủ đất, độ cao (biến môi trường)
2. t+3/t+7 mới 1 seed
3. Moran's I chưa có permutation test
4. OOD detection chưa đánh giá trên data thật
5. Synthetic không tái lập đầy đủ kết quả Phase A
