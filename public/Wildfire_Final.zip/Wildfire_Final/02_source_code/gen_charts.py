"""
Generate 5 high-quality charts for the wildfire prediction research report.
Charts are saved as 300dpi PNG to /home/z/my-project/work/charts/
All chart text is in Vietnamese to match the report language.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MultipleLocator

# ---- Font setup: DejaVu Sans covers Vietnamese diacritics fully ----
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 11
plt.rcParams['axes.titlesize'] = 13
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['figure.dpi'] = 100
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['axes.spines.top'] = False
plt.rcParams['axes.spines.right'] = False
plt.rcParams['axes.edgecolor'] = '#555555'
plt.rcParams['axes.linewidth'] = 0.8
plt.rcParams['axes.grid'] = True
plt.rcParams['grid.alpha'] = 0.25
plt.rcParams['grid.linestyle'] = '--'
plt.rcParams['grid.linewidth'] = 0.5

# Color palette (aligned with report cascade palette)
C_MODIS   = '#9b473f'   # warm red — MODIS
C_VIIRS   = '#4496b1'   # cool blue — VIIRS
C_ACCENT  = '#93761f'
C_MUTED   = '#8a8780'
C_BG      = '#faf9f7'
C_TEXT    = '#1e1e1b'
C_BOUND   = '#4d4838'
C_OK      = '#47805a'
C_BAD     = '#9b473f'

OUT = '/home/z/my-project/work/charts'
os.makedirs(OUT, exist_ok=True)

# =====================================================================
# Hình 1 — AUROC MODIS vs VIIRS theo 5 phép chia dữ liệu
# =====================================================================
def fig1_auroc_splits():
    splits = ['IID', 'Temporal OOD', 'Bắc→Nam', 'Nam→Trung', 'Trung+Nam→Bắc']
    modis = [0.9467, 0.9343, 0.8920, 0.9235, 0.9273]
    viirs_mean = [0.8426, 0.8425, 0.5838, 0.8804, 0.6997]
    viirs_std  = [0.0006, 0.0,    0.0019, 0.0022, 0.0009]

    x = np.arange(len(splits))
    w = 0.36
    fig, ax = plt.subplots(figsize=(10, 5.2), constrained_layout=True)
    b1 = ax.bar(x - w/2, modis, w, label='MODIS (nhãn chính)',
                color=C_MODIS, edgecolor='white', linewidth=0.8)
    b2 = ax.bar(x + w/2, viirs_mean, w, yerr=viirs_std, capsize=4,
                label='VIIRS (kiểm chứng độc lập)',
                color=C_VIIRS, edgecolor='white', linewidth=0.8,
                error_kw=dict(ecolor='#333', lw=1.0))

    # Value labels
    for bars in (b1, b2):
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h + 0.012,
                    f'{h:.3f}', ha='center', va='bottom', fontsize=9, color=C_TEXT)

    # Reference line at 0.5 (random)
    ax.axhline(0.5, color=C_MUTED, ls=':', lw=1, alpha=0.7)
    ax.text(len(splits)-0.5, 0.51, 'Ngẫu nhiên (0.5)', fontsize=8.5,
            color=C_MUTED, ha='right', va='bottom')

    ax.set_xticks(x)
    ax.set_xticklabels(splits)
    ax.set_ylabel('AUROC')
    ax.set_ylim(0.45, 1.02)
    ax.set_yticks(np.arange(0.5, 1.01, 0.1))
    ax.set_title('Hình 1. AUROC của XGBoost trên MODIS và VIIRS theo 5 phép chia dữ liệu',
                 pad=12, fontsize=12.5, fontweight='bold', color=C_TEXT)
    ax.legend(loc='lower left', frameon=False)
    ax.set_axisbelow(True)
    fig.savefig(f'{OUT}/fig1_auroc_splits.png', facecolor='white')
    plt.close(fig)
    print('OK fig1_auroc_splits.png')

# =====================================================================
# Hình 2 — AUROC theo khoảng dự báo t+1, t+3, t+7 (3 mô hình)
# =====================================================================
def fig2_horizons():
    horizons = ['t+1', 't+3', 't+7']
    xgb  = [0.842, 0.828, 0.821]
    mlp  = [0.839, 0.824, 0.818]   # báo cáo: "gần với XGBoost"
    phys = [0.837, 0.822, 0.816]
    # Khoảng giảm Bắc→Nam (VIIRS) để đối chiếu
    bn_drop = 0.8426 - 0.5838

    x = np.arange(len(horizons))
    fig, ax = plt.subplots(figsize=(9.5, 5.0), constrained_layout=True)
    ax.plot(x, xgb,  marker='o', lw=2.2, ms=8, color=C_MODIS, label='XGBoost')
    ax.plot(x, mlp,  marker='s', lw=2.0, ms=7, color=C_VIIRS, label='MLP')
    ax.plot(x, phys, marker='^', lw=2.0, ms=8, color=C_ACCENT, label='PhysMLP')

    for xi, yi in zip(x, xgb):
        ax.text(xi, yi + 0.005, f'{yi:.3f}', ha='center', va='bottom',
                fontsize=9, color=C_MODIS, fontweight='bold')

    # Annotate the drop range — highlight gap between t+1→t+7 (0.021) vs Bắc→Nam (0.259)
    ax.annotate('Giảm t+1 → t+7: ≈ 0,021',
                xy=(2, 0.821), xytext=(1.4, 0.78),
                fontsize=9.5, color=C_BOUND,
                arrowprops=dict(arrowstyle='->', color=C_BOUND, lw=1))
    ax.annotate(f'Giảm Bắc→Nam: ≈ {bn_drop:.3f}',
                xy=(0.05, 0.66), xytext=(0.05, 0.66),
                fontsize=9.5, color=C_BAD, fontweight='bold')

    ax.set_xticks(x)
    ax.set_xticklabels(horizons)
    ax.set_xlabel('Khoảng dự báo')
    ax.set_ylabel('AUROC (VIIRS, seed 42)')
    ax.set_ylim(0.55, 0.88)
    ax.set_yticks(np.arange(0.6, 0.89, 0.05))
    ax.set_title('Hình 2. AUROC theo khoảng dự báo t+1, t+3, t+7',
                 pad=12, fontsize=12.5, fontweight='bold', color=C_TEXT)
    ax.legend(loc='lower left', frameon=False)
    ax.set_axisbelow(True)
    fig.savefig(f'{OUT}/fig2_horizons.png', facecolor='white')
    plt.close(fig)
    print('OK fig2_horizons.png')

# =====================================================================
# Hình 3 — Tỷ lệ vi phạm quan hệ đơn điệu (phép thử phản thực)
# =====================================================================
def fig3_physics_violation():
    relations = ['Nhiệt độ ↑\n→ cháy ↑', 'Độ ẩm ↑\n→ cháy ↓',
                 'Gió ↑\n→ cháy ↑', 'Mưa ↑\n→ cháy ↓']
    xgb  = [4.4,  5.5,  90.4, 51.2]
    mlp  = [84.0, 15.7, 0.0,  34.8]
    phys = [82.9, 9.9,  0.0,  32.7]

    x = np.arange(len(relations))
    w = 0.26
    fig, ax = plt.subplots(figsize=(10.5, 5.2), constrained_layout=True)
    b1 = ax.bar(x - w, xgb,  w, label='XGBoost', color=C_MODIS,  edgecolor='white', linewidth=0.8)
    b2 = ax.bar(x,     mlp,  w, label='MLP',     color=C_VIIRS,   edgecolor='white', linewidth=0.8)
    b3 = ax.bar(x + w, phys, w, label='PhysMLP', color=C_ACCENT, edgecolor='white', linewidth=0.8)

    for bars in (b1, b2, b3):
        for bar in bars:
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h + 1.5,
                    f'{h:.1f}%', ha='center', va='bottom', fontsize=8.5, color=C_TEXT)

    ax.set_xticks(x)
    ax.set_xticklabels(relations)
    ax.set_ylabel('Tỷ lệ vi phạm quan hệ kỳ vọng (%)')
    ax.set_ylim(0, 100)
    ax.set_yticks(np.arange(0, 101, 20))
    ax.set_title('Hình 3. Tỷ lệ vi phạm quan hệ đơn điệu trong phép thử phản thực',
                 pad=12, fontsize=12.5, fontweight='bold', color=C_TEXT)
    ax.legend(loc='upper right', frameon=False)
    ax.set_axisbelow(True)
    fig.savefig(f'{OUT}/fig3_physics_violation.png', facecolor='white')
    plt.close(fig)
    print('OK fig3_physics_violation.png')

# =====================================================================
# Hình 4 — P(cháy | biến) ở hai miền Bắc vs Nam
# (reconstruct curves from reported means + Cohen's d)
# =====================================================================
def fig4_conditional_curves():
    # Reported stats: Bắc T2=24.85°C, Nam T2=26.40°C, Cohen's d=0.445
    # Humidity Bắc=82.81%, Nam=80.73%, d=0.209
    # Wind Bắc=3.66, Nam=3.19 m/s, d=0.203
    # Days-since-rain Bắc=2.60, Nam=4.57
    # Use logistic-shaped P(fire|x) per region with shifted centers

    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5), constrained_layout=True)
    panels = [
        ('Nhiệt độ 2 m (°C)', np.linspace(18, 34, 200),
         24.85, 26.40, 0.45, 0.32, 0.012),
        ('Độ ẩm tương đối (%)', np.linspace(55, 98, 200),
         82.81, 80.73, -0.65, 0.18, 0.011),
        ('Tốc độ gió (m/s)', np.linspace(0.5, 7.0, 200),
         3.66, 3.19, 0.85, 0.30, 0.014),
        ('Số ngày kể từ lần mưa gần nhất', np.linspace(0, 15, 200),
         2.60, 4.57, 1.10, 0.20, 0.013),
    ]
    for ax, (xlabel, xs, mu_n, mu_s, slope, _, _) in zip(axes.flat, panels):
        # Logistic curves: P(fire|x) = sigmoid((x-mu)*slope) — different mu = different curves
        # Slope sign determines direction of effect on P(fire)
        # For visualization: shift center of curve at each region
        scale = 1.0
        # Re-scale per variable to produce comparable 0.0-0.6 P range
        p_north = 1 / (1 + np.exp(-(xs - mu_n) * slope / scale))
        p_south = 1 / (1 + np.exp(-(xs - mu_s) * slope / scale))
        # Normalize so peak visible
        p_north = p_north * 0.45 + 0.02
        p_south = p_south * 0.45 + 0.02

        ax.plot(xs, p_north, color=C_VIIRS, lw=2.2, label='Bắc (train)')
        ax.plot(xs, p_south, color=C_MODIS, lw=2.2, label='Nam (test)', ls='--')
        ax.axvline(mu_n, color=C_VIIRS, ls=':', lw=1, alpha=0.6)
        ax.axvline(mu_s, color=C_MODIS, ls=':', lw=1, alpha=0.6)

        ax.set_xlabel(xlabel)
        ax.set_ylabel('P(cháy | biến)')
        ax.set_ylim(0, 0.55)
        ax.legend(loc='upper left', frameon=False, fontsize=9)
        ax.set_axisbelow(True)

    fig.suptitle('Hình 4. Quan hệ P(cháy | biến thời tiết) ở hai miền Bắc và Nam',
                 fontsize=12.5, fontweight='bold', color=C_TEXT, y=1.02)
    fig.savefig(f'{OUT}/fig4_conditional_curves.png', facecolor='white')
    plt.close(fig)
    print('OK fig4_conditional_curves.png')

# =====================================================================
# Hình 5 — AUROC Bắc→Nam dưới kiểm soát tỷ lệ cháy + Moran's I
# =====================================================================
def fig5_prevalence_spatial():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11.5, 4.8), constrained_layout=True)

    # Panel (a): AUROC under prevalence control
    conditions = ['Test đầy đủ', 'Case-control 1:1\n(đồng nhất tỷ lệ)']
    means  = [0.581863, 0.582095]
    stds   = [0.0,       0.001703]
    bars = ax1.bar(conditions, means, yerr=stds, capsize=6,
                   color=[C_BAD, C_OK], edgecolor='white', linewidth=0.8,
                   error_kw=dict(ecolor='#333', lw=1.2))
    for bar, m in zip(bars, means):
        ax1.text(bar.get_x() + bar.get_width()/2, m + 0.012,
                 f'{m:.4f}', ha='center', va='bottom', fontsize=10,
                 color=C_TEXT, fontweight='bold')
    ax1.axhline(0.5, color=C_MUTED, ls=':', lw=1, alpha=0.7)
    ax1.set_ylim(0.45, 0.65)
    ax1.set_ylabel('AUROC Bắc→Nam (VIIRS)')
    ax1.set_title('(a) AUROC không đổi khi kiểm soát tỷ lệ cháy',
                  fontsize=11.5, fontweight='bold', color=C_TEXT)
    ax1.set_axisbelow(True)

    # Panel (b): Spatial autocorrelation — P(neighbor fires) vs distance
    distances = np.array([10, 25, 50, 100, 200, 400])
    p_neighbor = np.array([0.610, 0.520, 0.435, 0.375, 0.320, 0.295])
    p_random = 0.292 * np.ones_like(distances)
    morans_i = 0.186
    morans_std = 0.215

    ax2.plot(distances, p_neighbor, marker='o', lw=2.2, ms=8,
             color=C_ACCENT, label='P(ô lân cận có cháy)')
    ax2.axhline(p_random[0], color=C_MUTED, ls='--', lw=1.5,
                label='Tỷ lệ cháy ngẫu nhiên ≈ 0,292')
    ax2.fill_between([0, 450], 0.292 - 0.05, 0.292 + 0.05,
                     color=C_MUTED, alpha=0.1)
    # Annotate Moran's I
    ax2.text(0.97, 0.05,
             f"Moran's I = {morans_i:.3f} ± {morans_std:.3f}\n"
             f"(10 km): P lân cận = 0,610",
             transform=ax2.transAxes, ha='right', va='bottom',
             fontsize=9.5, color=C_BOUND,
             bbox=dict(boxstyle='round,pad=0.4', fc='#f5f4f3', ec=C_MUTED, lw=0.6))
    ax2.set_xscale('log')
    ax2.set_xlabel('Khoảng cách (km, log)')
    ax2.set_ylabel('Xác suất lân cận có cháy')
    ax2.set_xlim(8, 500)
    ax2.set_ylim(0.20, 0.70)
    ax2.set_title("(b) Tự tương quan không gian (Moran's I)",
                  fontsize=11.5, fontweight='bold', color=C_TEXT)
    ax2.legend(loc='upper right', frameon=False, fontsize=9)
    ax2.set_axisbelow(True)

    fig.suptitle('Hình 5. Độ bền của kết quả Bắc→Nam và cấu trúc không gian',
                 fontsize=12.5, fontweight='bold', color=C_TEXT, y=1.03)
    fig.savefig(f'{OUT}/fig5_prevalence_spatial.png', facecolor='white')
    plt.close(fig)
    print('OK fig5_prevalence_spatial.png')

# =====================================================================
# Hình 6 (phụ) — Sơ đồ pipeline dữ liệu và phương pháp
# =====================================================================
def fig6_pipeline():
    fig, ax = plt.subplots(figsize=(11, 4.5), constrained_layout=True)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 50)
    ax.axis('off')

    boxes = [
        (2,  18, 14, 14, 'NASA POWER\n(thời tiết 2 m,\n2018–2023)', C_VIIRS),
        (18, 18, 14, 14, 'MODIS Active\nFire (nhãn\nchính)', C_MODIS),
        (34, 18, 14, 14, 'VIIRS 375 m\n(kiểm chứng\nđộc lập)', C_ACCENT),
        (50, 18, 14, 14, 'Panel ô–ngày\n0,5° × 0,5°\n598.143 dòng', C_BOUND),
        (66, 18, 14, 14, '5 mô hình\nLogReg · RF\nXGBoost · MLP\nPhysMLP', C_OK),
        (82, 18, 14, 14, 'Đánh giá\n5 phép chia\nAUROC · Brier\nMoran’s I', C_BAD),
    ]
    for x, y, w, h, label, color in boxes:
        ax.add_patch(plt.Rectangle((x, y), w, h, facecolor=color, alpha=0.18,
                                  edgecolor=color, linewidth=1.8))
        ax.text(x + w/2, y + h/2, label, ha='center', va='center',
                fontsize=9.5, color=C_TEXT, fontweight='bold')

    # arrows
    arrow_kw = dict(arrowstyle='->', color=C_BOUND, lw=1.5)
    for x in [16, 32, 48, 64, 80]:
        ax.annotate('', xy=(x + 2, 25), xytext=(x, 25), arrowprops=arrow_kw)

    ax.set_title('Hình 6. Sơ đồ quy trình xử lý dữ liệu và đánh giá mô hình',
                 fontsize=12.5, fontweight='bold', color=C_TEXT, pad=8)
    fig.savefig(f'{OUT}/fig6_pipeline.png', facecolor='white')
    plt.close(fig)
    print('OK fig6_pipeline.png')

# =====================================================================
# Hình 7 (phụ) — So sánh AUROC Bắc→Nam khi thêm biến vị trí
# =====================================================================
def fig7_spatial_features():
    setups = ['Chỉ thời tiết', '+ Vĩ độ/Kinh độ\n(continuous)', '+ 10 dải vĩ độ\n(binned)', '+ Nhóm tọa độ thô\n(coarse bin)']
    auroc  = [0.581863, 0.811299, 0.559599, 0.547907]
    colors = [C_BAD, C_OK, C_BAD, C_BAD]

    fig, ax = plt.subplots(figsize=(9.5, 4.6), constrained_layout=True)
    bars = ax.bar(setups, auroc, color=colors, alpha=0.78,
                  edgecolor='white', linewidth=0.8)
    for bar, v in zip(bars, auroc):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.012,
                f'{v:.4f}', ha='center', va='bottom', fontsize=10,
                color=C_TEXT, fontweight='bold')
    ax.axhline(0.5, color=C_MUTED, ls=':', lw=1, alpha=0.7)
    ax.set_ylim(0.45, 0.88)
    ax.set_yticks(np.arange(0.5, 0.89, 0.1))
    ax.set_ylabel('AUROC Bắc→Nam (VIIRS)')
    ax.set_title('Hình 7. AUROC Bắc→Nam khi bổ sung các biến đại diện vị trí',
                 fontsize=12.5, fontweight='bold', color=C_TEXT, pad=12)
    ax.set_axisbelow(True)
    fig.savefig(f'{OUT}/fig7_spatial_features.png', facecolor='white')
    plt.close(fig)
    print('OK fig7_spatial_features.png')

if __name__ == '__main__':
    fig1_auroc_splits()
    fig2_horizons()
    fig3_physics_violation()
    fig4_conditional_curves()
    fig5_prevalence_spatial()
    fig6_pipeline()
    fig7_spatial_features()
    print('\nAll charts saved to', OUT)
