"""
Merge cover.pdf + body.pdf → final report PDF
Normalize cover page size to A4 (595.276 x 841.890 pt) to match body.
"""
import sys
from pypdf import PdfWriter, PdfReader
from pypdf.generic import RectangleObject
import os

COVER = '/home/z/my-project/work/cover.pdf'
BODY  = '/home/z/my-project/work/body.pdf'
OUT   = '/home/z/my-project/download/Bao_cao_KHKT_Du_bao_chay_rung_V9.pdf'

# A4 in points: 595.276 × 841.890 (matches reportlab.pagesizes.A4)
A4_W = 595.276
A4_H = 841.890

writer = PdfWriter()

# Cover — normalize page size to A4 exactly
cov = PdfReader(COVER)
for p in cov.pages:
    # Force-set media & crop boxes to A4 exact
    p.mediabox = RectangleObject([0, 0, A4_W, A4_H])
    p.cropbox  = RectangleObject([0, 0, A4_W, A4_H])
    p.bleedbox = RectangleObject([0, 0, A4_W, A4_H])
    p.trimbox  = RectangleObject([0, 0, A4_W, A4_H])
    p.artbox   = RectangleObject([0, 0, A4_W, A4_H])
    writer.add_page(p)

# Body
bod = PdfReader(BODY)
for p in bod.pages:
    writer.add_page(p)

# Set metadata
writer.add_metadata({
    '/Title': 'Đánh giá độ tin cậy và khả năng khái quát không gian của mô hình dự báo cháy rừng dựa trên dữ liệu vệ tinh',
    '/Author': 'Hoàng Bảo Lâm',
    '/Subject': 'Báo cáo KHKT — Dự báo cháy rừng dựa trên dữ liệu vệ tinh (MODIS, VIIRS, NASA POWER)',
    '/Creator': 'Z.ai',
    '/Keywords': 'cháy rừng; MODIS; VIIRS; XGBoost; kiểm tra ngoài miền; khái quát không gian; PhysMLP; Moran\'s I; NASA POWER',
})

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'wb') as f:
    writer.write(f)

# Stats
size_kb = os.path.getsize(OUT) / 1024
total_pages = len(cov.pages) + len(bod.pages)
print(f'✓ Merged final PDF: {OUT}')
print(f'  Pages: {total_pages} (cover={len(cov.pages)}, body={len(bod.pages)})')
print(f'  Size:  {size_kb:.1f} KB ({size_kb/1024:.2f} MB)')
