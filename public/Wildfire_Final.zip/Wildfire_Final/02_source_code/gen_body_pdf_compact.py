"""
Generate COMPACT body PDF for wildfire prediction research report.
Target: ~13 body pages + 1 cover = 14 total ≤ 15 pages.

Compact optimizations:
- Tighter margins (18mm vs 22mm)
- Smaller body font (10pt vs 11pt)
- Smaller line height (14pt vs 16.5pt)
- Remove TOC (save 1 page)
- Merge Tóm tắt + Part 1 onto same flow
- Remove Hình 6 (pipeline) and Hình 7 (spatial_features) — keep 5 core charts
- Remove Bảng 1 (data stats) and Bảng 3 (metrics list)
- Tighter spacing, fewer callouts
- Merge H3 subsections inline
"""
import os
import hashlib
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak,
    Table, TableStyle, KeepTogether, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.pdfgen import canvas

# ─────────────────────────────────────────────────────────
# Font registration
# ─────────────────────────────────────────────────────────
FONT_DIR = '/usr/share/fonts'

pdfmetrics.registerFont(TTFont('BodySerif',       f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf'))
pdfmetrics.registerFont(TTFont('BodySerif-Bold',  f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf'))
pdfmetrics.registerFont(TTFont('BodySerif-Italic',f'{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Light.ttf'))
registerFontFamily('BodySerif', normal='BodySerif', bold='BodySerif-Bold', italic='BodySerif-Italic', boldItalic='BodySerif-Bold')

pdfmetrics.registerFont(TTFont('HeadSans',         f'{FONT_DIR}/truetype/liberation/LiberationSans-Regular.ttf'))
pdfmetrics.registerFont(TTFont('HeadSans-Bold',    f'{FONT_DIR}/truetype/liberation/LiberationSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('HeadSans-Oblique', f'{FONT_DIR}/truetype/liberation/LiberationSans-Italic.ttf'))
registerFontFamily('HeadSans', normal='HeadSans', bold='HeadSans-Bold', italic='HeadSans-Oblique', boldItalic='HeadSans-Bold')

# ─────────────────────────────────────────────────────────
# Palette (same as full version)
# ─────────────────────────────────────────────────────────
HEADER_FILL   = colors.HexColor('#4d4838')
BORDER        = colors.HexColor('#d1cec6')
CARD_BG       = colors.HexColor('#edece9')
TABLE_STRIPE  = colors.HexColor('#f1f0ee')
ACCENT        = colors.HexColor('#93761f')
ACCENT_2      = colors.HexColor('#4496b1')
TEXT_PRIMARY  = colors.HexColor('#1e1e1b')
TEXT_MUTED    = colors.HexColor('#8a8780')
SEM_SUCCESS   = colors.HexColor('#47805a')
SEM_WARNING   = colors.HexColor('#a48343')
SEM_ERROR     = colors.HexColor('#9b473f')
SEM_INFO      = colors.HexColor('#4d6e8e')

TABLE_HEADER_COLOR = HEADER_FILL
TABLE_HEADER_TEXT   = colors.white
TABLE_ROW_EVEN      = colors.white
TABLE_ROW_ODD       = TABLE_STRIPE

# ─────────────────────────────────────────────────────────
# Compact Page geometry — tighter margins
# ─────────────────────────────────────────────────────────
PAGE_W, PAGE_H = A4
LEFT_MARGIN  = 18 * mm
RIGHT_MARGIN = 18 * mm
TOP_MARGIN   = 18 * mm
BOT_MARGIN   = 16 * mm
CONTENT_W    = PAGE_W - LEFT_MARGIN - RIGHT_MARGIN  # ~174mm

# ─────────────────────────────────────────────────────────
# Compact Styles — smaller fonts & spacing (but readable)
# ─────────────────────────────────────────────────────────
PART_TITLE = ParagraphStyle('PartTitle',
    fontName='HeadSans-Bold', fontSize=15, leading=19,
    textColor=HEADER_FILL, alignment=TA_LEFT,
    spaceBefore=14, spaceAfter=10, keepWithNext=True)

H2 = ParagraphStyle('H2',
    fontName='HeadSans-Bold', fontSize=12, leading=15.5,
    textColor=HEADER_FILL, alignment=TA_LEFT,
    spaceBefore=10, spaceAfter=5, keepWithNext=True)

H3 = ParagraphStyle('H3',
    fontName='HeadSans-Bold', fontSize=10.5, leading=14,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    spaceBefore=6, spaceAfter=3, keepWithNext=True)

BODY = ParagraphStyle('Body',
    fontName='BodySerif', fontSize=10.5, leading=14.5,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY,
    spaceBefore=1, spaceAfter=5, firstLineIndent=14)

BODY_NOINDENT = ParagraphStyle('BodyNoIndent',
    fontName='BodySerif', fontSize=10.5, leading=14.5,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY,
    spaceBefore=1, spaceAfter=5)

ABSTRACT = ParagraphStyle('Abstract',
    fontName='BodySerif', fontSize=10, leading=14,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY,
    leftIndent=12, rightIndent=12,
    spaceBefore=2, spaceAfter=5)

ABSTRACT_BODY = ParagraphStyle('AbstractBody',
    fontName='BodySerif', fontSize=10, leading=14.5,
    textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY,
    leftIndent=12, rightIndent=12,
    spaceBefore=2, spaceAfter=5)

KEYWORDS = ParagraphStyle('Keywords',
    fontName='HeadSans-Oblique', fontSize=9.5, leading=13,
    textColor=TEXT_MUTED, alignment=TA_LEFT,
    leftIndent=12, rightIndent=12,
    spaceBefore=5, spaceAfter=8)

CAPTION = ParagraphStyle('Caption',
    fontName='HeadSans-Oblique', fontSize=9, leading=12,
    textColor=TEXT_MUTED, alignment=TA_CENTER,
    spaceBefore=3, spaceAfter=10)

TABLE_CAP = ParagraphStyle('TableCap',
    fontName='HeadSans-Oblique', fontSize=9, leading=12,
    textColor=TEXT_MUTED, alignment=TA_CENTER,
    spaceBefore=3, spaceAfter=10)

REF_ITEM = ParagraphStyle('RefItem',
    fontName='BodySerif', fontSize=9, leading=12,
    textColor=TEXT_PRIMARY, alignment=TA_LEFT,
    leftIndent=20, firstLineIndent=-20,
    spaceBefore=1, spaceAfter=3)

# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────
def add_para(story, text, style=BODY):
    story.append(Paragraph(text, style))

def add_spacer(story, h=3):
    story.append(Spacer(1, h))

def add_heading_inline(story, text, style=H2):
    """Heading without TOC bookmark (compact: no TOC)."""
    story.append(Paragraph(text, style))

def add_image(story, path, caption=None, max_h=420):
    """Compact image embedding — default max_h = 420pt."""
    width = CONTENT_W * 0.92
    from PIL import Image as PILImage
    pil = PILImage.open(path)
    aspect = pil.size[1] / pil.size[0]
    h = width * aspect
    if h > max_h:
        h = max_h
        width = h / aspect
    img = Image(path, width=width, height=h)
    block = [img]
    if caption:
        block.append(Paragraph(caption, CAPTION))
    story.append(KeepTogether(block))

def add_table(story, header, rows, col_widths, caption=None, font_size=8.5):
    data = [header] + rows
    cell_style = ParagraphStyle('cell',
        fontName='BodySerif', fontSize=font_size, leading=font_size*1.3,
        textColor=TEXT_PRIMARY, alignment=TA_LEFT)
    head_cell_style = ParagraphStyle('head_cell',
        fontName='HeadSans-Bold', fontSize=font_size, leading=font_size*1.3,
        textColor=colors.white, alignment=TA_CENTER)
    wrapped = []
    for i, row in enumerate(data):
        wrapped_row = []
        for cell in row:
            if i == 0:
                wrapped_row.append(Paragraph(str(cell), head_cell_style))
            else:
                wrapped_row.append(Paragraph(str(cell), cell_style))
        wrapped.append(wrapped_row)

    t = Table(wrapped, colWidths=col_widths, repeatRows=1)
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER_COLOR),
        ('TEXTCOLOR',  (0, 0), (-1, 0), TABLE_HEADER_TEXT),
        ('ALIGN',      (0, 0), (-1, 0), 'CENTER'),
        ('VALIGN',     (0, 0), (-1, -1), 'MIDDLE'),
        ('LINEBELOW',  (0, 0), (-1, 0), 1.0, HEADER_FILL),
        ('LINEBELOW',  (0, -1), (-1, -1), 0.8, HEADER_FILL),
        ('LINEABOVE',  (0, 0), (-1, 0), 1.0, HEADER_FILL),
        ('TOPPADDING',    (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('LEFTPADDING',   (0, 0), (-1, -1), 4),
        ('RIGHTPADDING',  (0, 0), (-1, -1), 4),
    ]
    for i in range(1, len(data)):
        if i % 2 == 1:
            style.append(('BACKGROUND', (0, i), (-1, i), TABLE_ROW_ODD))
        else:
            style.append(('BACKGROUND', (0, i), (-1, i), TABLE_ROW_EVEN))
    t.setStyle(TableStyle(style))
    block = [t]
    if caption:
        block.append(Paragraph(caption, TABLE_CAP))
    story.append(KeepTogether(block))
    add_spacer(story, 2)

def add_callout_compact(story, text, color=ACCENT):
    """Compact callout — single paragraph, no title."""
    body_style = ParagraphStyle('cb_b',
        fontName='BodySerif', fontSize=9.5, leading=12.5,
        textColor=TEXT_PRIMARY, alignment=TA_JUSTIFY)
    inner = [Paragraph(text, body_style)]
    t = Table([[inner]], colWidths=[CONTENT_W])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), CARD_BG),
        ('LEFTPADDING', (0, 0), (-1, -1), 10),
        ('RIGHTPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LINEBEFORE', (0, 0), (0, -1), 2.5, color),
    ]))
    story.append(KeepTogether([t]))
    add_spacer(story, 4)

# ─────────────────────────────────────────────────────────
# Page header / footer (compact)
# ─────────────────────────────────────────────────────────
def draw_header_footer(canv, doc):
    canv.saveState()
    canv.setFont('HeadSans', 8)
    canv.setFillColor(TEXT_MUTED)
    page_num = canv.getPageNumber()
    # Centered page number
    canv.drawCentredString(PAGE_W / 2, 9 * mm, f'·  {page_num}  ·')
    # Footer left
    canv.setFont('HeadSans-Oblique', 7.5)
    canv.drawString(LEFT_MARGIN, 9 * mm,
                    'Báo cáo KHKT — Dự báo cháy rừng dựa trên dữ liệu vệ tinh')
    canv.drawRightString(PAGE_W - RIGHT_MARGIN, 9 * mm,
                        'Hoàng Bảo Lâm · 10/2026')
    # Top thin rule
    canv.setStrokeColor(BORDER)
    canv.setLineWidth(0.4)
    canv.line(LEFT_MARGIN, PAGE_H - TOP_MARGIN + 6,
              PAGE_W - RIGHT_MARGIN, PAGE_H - TOP_MARGIN + 6)
    canv.setFont('HeadSans', 8)
    canv.setFillColor(TEXT_MUTED)
    canv.drawString(LEFT_MARGIN, PAGE_H - TOP_MARGIN + 9,
                    'Đánh giá độ tin cậy và khả năng khái quát không gian')
    canv.drawRightString(PAGE_W - RIGHT_MARGIN, PAGE_H - TOP_MARGIN + 9,
                         'Báo cáo V9.0 — Compact')
    canv.restoreState()

# ─────────────────────────────────────────────────────────
# Build compact story
# ─────────────────────────────────────────────────────────
def build_story():
    story = []
    CHARTS = '/home/z/my-project/work/charts'

    # ============================================================
    # TÓM TẮT  (compact, 1 short para)
    # ============================================================
    add_heading_inline(story, 'TÓM TẮT', H2)
    add_para(story,
        'Báo cáo đặt câu hỏi: mô hình dự báo cháy đạt điểm cao trên tập kiểm tra cùng '
        'miền có khái quát được sang vùng chưa từng thấy hay không? Nếu hiệu năng suy '
        'giảm, nguyên nhân nằm ở đâu? Ràng buộc vật lý có cải thiện khả năng khái quát '
        'ngoài miền không?', style=ABSTRACT)
    add_para(story,
        'Bộ dữ liệu gồm <b>598.143 quan sát ô–ngày</b>, 273 ô 0,5° tại Việt Nam 2018–2023; '
        'thời tiết từ <b>NASA POWER</b> [5], <b>MODIS</b> [2] làm nhãn chính, <b>VIIRS</b> '
        '[3] kiểm chứng độc lập. Năm mô hình (LogReg, RF [8], XGBoost [1], MLP, PhysMLP '
        '[6]) đánh giá qua 5 phép chia (IID, Temporal, Bắc→Nam, Nam→Trung, Trung+Nam→Bắc) '
        'với hiệu chuẩn isotonic [7]. Tổng cộng 200 lượt chạy thí nghiệm.', style=ABSTRACT_BODY)
    add_para(story,
        'Kết quả nổi bật: Bắc→Nam trên VIIRS cho AUROC 0,5838 ± 0,0019 (gần ngẫu nhiên), '
        'so với 0,8426 IID; trong khi t+1→t+7 chỉ giảm ≈0,02. Sụt giảm không do tỷ lệ cháy '
        'mà do distribution shift, concept drift, tự tương quan không gian (Moran\'s I ≈ '
        '0,186) và tín hiệu địa lý chưa mô hình hóa. Khi bổ sung lat/lon liên tục vào '
        'XGBoost, AUROC tăng vọt lên 0,8113 nhưng binned lại giảm — chỉ ra mô hình ghi nhớ '
        'vị trí chứ không học cơ chế.', style=ABSTRACT_BODY)
    add_para(story,
        '<b>Từ khóa:</b> cháy rừng; MODIS; VIIRS; XGBoost; kiểm tra ngoài miền; khái quát '
        'không gian; PhysMLP; Moran\'s I; NASA POWER.', style=KEYWORDS)
    add_spacer(story, 4)

    # ============================================================
    # PHẦN 1: MỞ ĐẦU & TỔNG QUAN TÀI LIỆU
    # ============================================================
    add_heading_inline(story, 'PHẦN 1. MỞ ĐẦU &amp; TỔNG QUAN TÀI LIỆU', PART_TITLE)
    add_para(story,
        'Phần này trình bày tính cấp thiết của đề tài, tổng quan các công trình nghiên cứu '
        'trong và ngoài nước về dự báo cháy rừng bằng học máy, chỉ ra khoảng trống nghiên '
        'cứu mà đề tài hướng tới giải quyết, đồng thời nêu rõ câu hỏi nghiên cứu, mục tiêu, '
        'giả thuyết khoa học và phạm vi áp dụng.', style=BODY_NOINDENT)
    add_spacer(story, 4)

    add_heading_inline(story, '1.1. Tính cấp thiết và lý do chọn đề tài', H2)
    add_para(story,
        'Cháy rừng là một trong những thảm họa thiên tai thường xuyên tại Việt Nam, gây '
        'thiệt hại lớn về rừng, tài sản và sức khỏe cộng đồng. Theo số liệu quan trắc vệ '
        'tinh, mỗi năm cả nước ghi nhận hàng nghìn điểm cháy, tập trung ở mùa khô Tây '
        'Nguyên, miền Bắc và miền Trung. Việc cảnh báo sớm là biện pháp hiệu quả nhất để '
        'giảm thiệt hại, nhưng các hệ thống cảnh báo hiện hành còn phụ thuộc nhiều vào kinh '
        'nghiệm và chỉ số thời tiết đơn lẻ, chưa tận dụng đầy đủ dữ liệu viễn thám và khả '
        'năng học từ dữ liệu của máy tính. Dữ liệu vệ tinh như MODIS [2], [4] và VIIRS [3] '
        'cung cấp thông tin điểm cháy quy mô toàn quốc; NASA POWER [5] cung cấp thời tiết '
        'tái phân tích đồng nhất theo không gian và thời gian. Khi kết hợp với học máy '
        '[1], [6], [8], có thể xây dựng mô hình dự báo xác suất cháy cho từng ô lưới theo '
        'ngày — nền tảng của hệ thống cảnh báo sớm diện rộng.')
    add_para(story,
        'Tuy nhiên, trong quá trình thử nghiệm tôi nhận thấy một vấn đề dễ bị bỏ qua: '
        '<i>mô hình có điểm số rất cao trên tập kiểm tra cùng miền chưa chắc đã đáng tin '
        'khi đưa sang vùng địa lý khác</i>. Các ô lưới gần nhau thường có thời tiết và tình '
        'trạng cháy tương tự, nên nếu chia dữ liệu IID ngẫu nhiên, các mẫu rất giống nhau '
        'có thể xuất hiện ở cả train và test — dẫn đến ước lượng quá lạc quan. Khi đó mô '
        'hình có thể đạt điểm cao mà chưa chắc đã học được một quy luật có thể áp dụng ở '
        'vùng mới. Đây là một vấn đề phương pháp luận quan trọng nhưng chưa được xem xét '
        'kỹ trong các nghiên cứu dự báo cháy rừng tại Việt Nam.')
    add_para(story,
        'Vì vậy đề tài không chỉ xây dựng mô hình dự báo mà còn thiết kế quy trình đánh giá '
        'đa chiều: (i) cùng miền theo cách ngẫu nhiên, (ii) ngoài miền thời gian, (iii) '
        'ngoài miền không gian với các hướng chuyển dịch khác nhau, và (iv) kiểm chứng bằng '
        'nguồn cảm biến độc lập. Cách tiếp cận này giúp phân biệt rõ trường hợp mô hình '
        'thực sự khái quát với trường hợp mô hình chỉ đang "ghi nhớ" đặc điểm của vùng đã '
        'học — đây chính là điểm mới cốt lõi của đề tài.')

    add_heading_inline(story, '1.2. Tổng quan tình hình nghiên cứu và khoảng trống', H2)
    add_para(story,
        '<b>Trong nước:</b> các nghiên cứu dự báo cháy rừng tại Việt Nam có thể chia thành '
        'hai nhóm. Nhóm thứ nhất sử dụng chỉ số thời tiết đơn lẻ (Mark-5, Nesterov, '
        'Angström) để phân cấp nguy cơ cháy theo ngày — đơn giản nhưng không tận dụng quan '
        'hệ phi tuyến giữa nhiều biến. Nhóm thứ hai mới bắt đầu áp dụng học máy (Random '
        'Forest [8], XGBoost [1]) trên dữ liệu MODIS, nhưng thường chia dữ liệu IID ngẫu '
        'nhiên và báo cáo độ chính xác trên chính dữ liệu đã dùng huấn luyện, dẫn đến ước '
        'lượng quá lạc quan. Một số nghiên cứu có dùng cả MODIS và VIIRS nhưng chỉ để so '
        'sánh số lượng điểm cháy, chưa tận dụng VIIRS như nguồn kiểm chứng độc lập.')
    add_para(story,
        '<b>Quốc tế:</b> bài toán dự báo cháy rừng bằng học máy đã được nghiên cứu sâu với '
        'các mô hình từ hồi quy logistic, Random Forest [8], gradient boosting [9], đến '
        'mạng nơ-ron và mô hình có ràng buộc vật lý (PhysMLP) [6]. Gần đây có quan tâm đến '
        '<b>khái quát ngoài miền</b> [11] và <b>cross-validation không gian</b> [12], nhưng '
        'thường chỉ dùng một phép chia theo vùng duy nhất, chưa đối chiếu với nguồn nhãn '
        'độc lập và chưa phân tách rõ các cơ chế nguyên nhân.')
    add_callout_compact(story,
        '<b>🔴 Khoảng trống nghiên cứu mà đề tài giải quyết:</b> chưa có nghiên cứu tại '
        'Việt Nam (1) đánh giá mô hình theo <b>5 phép chia</b> bao gồm ngoài miền không '
        'gian; (2) đối chiếu đồng thời <b>hai nguồn nhãn độc lập</b> MODIS và VIIRS; '
        '(3) phân tách nguyên nhân suy giảm theo 4 lớp (distribution shift, concept drift, '
        'prevalence, spatial autocorrelation); (4) kiểm tra tính nhất quán vật lý bằng '
        'PhysMLP.', color=SEM_ERROR)

    add_heading_inline(story, '1.3. Câu hỏi, mục tiêu và 5 giả thuyết khoa học', H2)
    add_para(story,
        'Từ khoảng trống nghiên cứu nêu trên, đề tài đặt ra ba câu hỏi nghiên cứu chính. '
        '<b>Thứ nhất</b>, mô hình dự báo cháy huấn luyện trên một miền địa lý có duy trì '
        'hiệu năng khi chuyển sang miền chưa từng thấy hay không? <b>Thứ hai</b>, nếu hiệu '
        'năng suy giảm, nguyên nhân thuộc về đâu: sự khác biệt phân phối thời tiết, sự thay '
        'đổi quan hệ giữa thời tiết và cháy, khác biệt tỷ lệ cháy, hay cấu trúc không gian? '
        '<b>Thứ ba</b>, các ràng buộc vật lý đưa vào mô hình có cải thiện khả năng khái quát '
        'ngoài miền hay không?')
    add_para(story,
        '<b>Mục tiêu cụ thể</b> bao gồm: (i) xây dựng bộ dữ liệu ô–ngày từ dữ liệu thời tiết '
        'và dữ liệu cháy vệ tinh; (ii) so sánh năm mô hình trong điều kiện cùng miền, ngoài '
        'miền thời gian và ngoài miền không gian; (iii) kiểm tra sự bền vững của kết luận khi '
        'chuyển từ nhãn MODIS sang VIIRS; (iv) chẩn đoán nguyên nhân của mức giảm Bắc→Nam '
        'bằng các thí nghiệm riêng về phân phối thời tiết, quan hệ điều kiện, tỷ lệ cháy và '
        'cấu trúc không gian; (v) kiểm tra xem việc đưa quan hệ vật lý đơn giản vào MLP có '
        'làm dự báo nhất quán hơn với kỳ vọng hay không.', style=BODY_NOINDENT)
    add_callout_compact(story,
        '<b>H1</b>: Phân phối thời tiết giữa miền Bắc và miền Nam khác nhau. '
        '<b>H2</b>: Quan hệ giữa điều kiện thời tiết và xác suất cháy thay đổi theo vùng. '
        '<b>H3</b>: Khác biệt giữa MODIS và VIIRS có thể làm thay đổi kết luận về độ tin '
        'cậy. <b>H4</b>: Có cấu trúc không gian chưa được biểu diễn đầy đủ bằng các biến '
        'thời tiết. <b>H5</b>: Tự tương quan không gian có thể làm đánh giá cùng miền trở '
        'nên lạc quan.',
        color=SEM_INFO)

    add_heading_inline(story, '1.4. Đối tượng và phạm vi nghiên cứu', H2)
    add_para(story,
        '<b>Đối tượng nghiên cứu</b> là các mô hình học máy dự báo xác suất cháy cho từng '
        'ô lưới theo ngày. Đề tài tập trung vào lãnh thổ Việt Nam trong giai đoạn '
        '2018–2023, sử dụng lưới 0,5° gồm 273 ô. Các biến đầu vào chính là dữ liệu thời '
        'tiết từ NASA POWER [5] và một số biến dẫn xuất từ chuỗi thời gian như số ngày '
        'kể từ lần mưa gần nhất. MODIS được dùng làm nguồn nhãn chính trong phần đánh giá, '
        'còn VIIRS được giữ riêng để kiểm tra xem kết luận có phụ thuộc quá nhiều vào một '
        'cảm biến hay không.')
    add_para(story,
        '<b>Phạm vi nghiên cứu</b> được giới hạn một cách có chủ đích. Ở phiên bản hiện '
        'tại, đề tài chưa đưa NDVI, lớp phủ đất, độ cao địa hình hoặc các biến về hoạt '
        'động của con người (như mật độ dân cư, canh tác nương rẫy, đường giao thông) vào '
        'mô hình. Đây là một giới hạn quan trọng, vì các yếu tố này được biết là ảnh '
        'hưởng đáng kể đến nguy cơ cháy. Tuy nhiên, việc tách chúng ra ở phiên bản đầu '
        'tiên có mục đích phương pháp luận: <i>nếu chỉ với các biến thời tiết, mô hình đã '
        'có dấu hiệu suy giảm khi chuyển miền, thì việc bổ sung các biến môi trường sau '
        'này có thể được đánh giá theo cùng một quy trình kiểm tra ngoài miền.</i>')

    # ============================================================
    # PHẦN 2: DỮ LIỆU VÀ PHƯƠNG PHÁP NGHIÊN CỨU
    # ============================================================
    add_heading_inline(story, 'PHẦN 2. DỮ LIỆU VÀ PHƯƠNG PHÁP NGHIÊN CỨU', PART_TITLE)
    add_para(story,
        'Phần này mô tả chi tiết ba nguồn dữ liệu (NASA POWER, MODIS, VIIRS), quy trình '
        'xây dựng panel ô–ngày, chiến lược chia dữ liệu kiểm tra ngoài miền, kiến trúc '
        'của năm mô hình thực nghiệm, và hệ thống chỉ số đánh giá bao gồm AUROC, Brier '
        'score, ECE và Moran\'s I.', style=BODY_NOINDENT)
    add_spacer(story, 4)

    add_heading_inline(story, '2.1. Dữ liệu và xây dựng panel ô–ngày', H2)
    add_para(story,
        'Bộ dữ liệu cuối cùng gồm <b>598.143 quan sát ô–ngày</b> (273 ô × 2.191 ngày) ghép '
        'từ ba nguồn: <b>NASA POWER</b> [5] cung cấp dữ liệu thời tiết tái phân tích theo '
        'lưới 0,5° với các biến T2M, RH2M, WS10M, PRECTOTCORR và biến dẫn xuất; <b>MODIS '
        'Active Fire</b> [2], [4] làm nhãn chính với độ phân giải 1 km, tần suất 2 lần/ngày '
        'từ vệ tinh Terra/Aqua; <b>VIIRS 375 m Active Fire</b> [3] trên vệ tinh Suomi-NPP '
        'giữ làm nguồn kiểm chứng độc lập, không tham gia huấn luyện. Đề tài đưa phát hiện '
        'cháy về cùng lưới 0,5° và cùng ngày; nếu một ô có nhiều phát hiện trong ngày vẫn '
        'chỉ tính 1 cell-day cháy. Ô không cháy được giữ lại (lớp âm) để mô hình nhìn thấy '
        'đầy đủ trường hợp không cháy — quan trọng vì nếu chỉ giữ điểm cháy, bài toán sẽ bị '
        'lệch ngay từ đầu.')
    add_para(story,
        '<b>Chống rò rỉ dữ liệu (data leakage):</b> mọi tham số chuẩn hóa chỉ học từ tập '
        'huấn luyện của từng phép chia; biến dẫn xuất như "số ngày không mưa" tính theo chuỗi '
        'thời gian của từng ô trước khi chia; hiệu chuẩn isotonic [7] chỉ fit trên validation, '
        'không dùng nhãn test. Nguyên tắc này đặc biệt quan trọng với phép chia Bắc→Nam — nếu '
        'dùng thông tin vùng kiểm tra để điều chỉnh, kết quả sẽ không còn phản ánh đúng khả '
        'năng chuyển miền. Tổng số cell-day cháy: MODIS 48.279, VIIRS 44.847; hai nguồn cùng '
        'đánh dấu 8.924 cell-day (Jaccard ≈ 0,106) — mức chồng lấn thấp cho thấy cần kiểm '
        'tra bằng nguồn độc lập.')

    add_heading_inline(story, '2.2. Năm chiến lược chia dữ liệu kiểm tra ngoài miền', H2)
    add_para(story,
        'Năm phép chia dữ liệu được sử dụng nhằm tách biệt ba câu hỏi khác nhau: mô hình '
        'chạy thế nào trong miền quen thuộc, có ổn định theo thời gian hay không, và có '
        'chuyển được sang vùng chưa thấy hay không. Cách thiết kế này quan trọng vì mỗi '
        'phép chia phản ánh một khía cạnh khác nhau của khả năng khái quát.')
    add_table(story,
        header=['Phép chia', 'Train', 'Test', 'Mục đích'],
        rows=[
            ['IID (theo nhóm ô)', 'Ô ngẫu nhiên', 'Ô ngẫu nhiên', 'Trong miền (lạc quan)'],
            ['Temporal OOD', '2018–2022', '2023', 'Chuyển thời gian'],
            ['Bắc → Nam', 'Phía Bắc', 'Phía Nam', 'Chuyển miền khó nhất'],
            ['Nam → Trung', 'Phía Nam', 'Miền Trung', 'Chuyển miền vừa'],
            ['Trung+Nam → Bắc', 'Trung+Nam', 'Phía Bắc', 'Chuyển miền ngược'],
        ],
        col_widths=[36*mm, 38*mm, 32*mm, 68*mm],
        caption='Bảng 1. Năm chiến lược chia dữ liệu.')
    add_para(story,
        'Ba phép chia cuối là <b>spatial splits</b> — vùng test không xuất hiện trong train '
        'ở bất kỳ ngày nào, kiểm tra trực tiếp khả năng chuyển miền. Phép IID theo nhóm ô '
        'giữ nguyên ý nghĩa "ngẫu nhiên" nhưng tránh rò rỉ cấp ô; Temporal OOD kiểm tra khả '
        'năng dự báo về tương lai: mô hình học từ 5 năm đầu và được kiểm tra trên năm cuối.',
        style=BODY_NOINDENT)

    add_heading_inline(story, '2.3. Năm mô hình thực nghiệm và chỉ số đánh giá', H2)
    add_para(story,
        'Năm mô hình được thử nghiệm đại diện cho các họ phương pháp khác nhau: <b>LogReg</b> '
        '(baseline tuyến tính), <b>Random Forest</b> [8] (bagging ensemble), <b>XGBoost</b> '
        '[1], [9] (gradient boosting — chọn làm mô hình chính cho chẩn đoán vì ổn định với '
        'dữ liệu bảng và dễ thiết lập thí nghiệm thêm/bớt biến), <b>MLP</b> (mạng nơ-ron '
        'truyền thẳng) và <b>PhysMLP</b> [6] (MLP có thành phần phạt 4 quan hệ đơn điệu: '
        'nhiệt độ↑→cháy↑, độ ẩm↑→cháy↓, gió↑→cháy↑, mưa↑→cháy↓). Đầu ra của tất cả mô hình '
        'là <b>xác suất cháy</b> chứ không phải nhãn 0/1, do đó hiệu chuẩn xác suất là bắt '
        'buộc trước khi báo cáo Brier score và ECE. PhysMLP được xem như <b>phép kiểm tra '
        'tính nhất quán</b>, không phải giải pháp cho khái quát ngoài miền.')
    add_para(story,
        '<b>Hiệu chuẩn xác suất</b> bằng isotonic regression [7] — phương pháp phi tham số '
        'phù hợp với bài toán phân loại mất cân bằng. <b>Các chỉ số đánh giá chính:</b> '
        'AUROC [10], [13] (chỉ số chính — khả năng xếp hạng ô nguy cơ cao hơn ô ít nguy cơ); '
        'Brier score (sai lệch bình phương xác suất); ECE (calibration error); Moran\'s I '
        '[10] (tự tương quan không gian); Cohen\'s d (khoảng cách chuẩn giữa phân phối); '
        'Jaccard (so sánh MODIS–VIIRS). Tổng cộng <b>200 lượt chạy</b>: 5 seed (42, 123, '
        '777, 2024, 31337) × 5 split × 5 model cho VIIRS t+1 (125 lượt) + t+3/t+7 seed 42 '
        '(50 lượt) + MODIS t+1 (25 lượt).', style=BODY_NOINDENT)

    # ============================================================
    # PHẦN 3: KẾT QUẢ NGHIÊN CỨU
    # ============================================================
    add_heading_inline(story, 'PHẦN 3. KẾT QUẢ NGHIÊN CỨU', PART_TITLE)
    add_para(story,
        'Phần này trình bày bốn nhóm kết quả chính: (1) so sánh hiệu năng giữa MODIS và '
        'VIIRS theo năm phép chia; (2) ảnh hưởng của khoảng dự báo t+1, t+3, t+7; (3) đánh '
        'giá tính nhất quán vật lý qua thí nghiệm phản thực; và (4) chẩn đoán chi tiết '
        'nguyên nhân suy giảm hiệu năng khi chuyển miền không gian Bắc → Nam.',
        style=BODY_NOINDENT)
    add_spacer(story, 4)

    add_heading_inline(story, '3.1. So sánh MODIS vs VIIRS theo các phép chia', H2)
    add_para(story,
        'Bảng 2 và Hình 1 trình bày AUROC của mô hình XGBoost (sau hiệu chuẩn xác suất) '
        'trên năm phép chia, cho cả hai nguồn nhãn. Điểm khác biệt lớn nhất nằm ở phép chia '
        '<b>Bắc→Nam</b>: MODIS cho AUROC 0,892 nhưng VIIRS chỉ còn 0,5838 ± 0,0019 — một '
        'sụt giảm nghiêm trọng, gần với mức ngẫu nhiên.')
    add_table(story,
        header=['Nguồn', 'IID', 'Temporal', 'Bắc→Nam', 'Nam→Trung', 'Trung+Nam→Bắc'],
        rows=[
            ['MODIS', '0,9467', '0,9343', '0,8920', '0,9235', '0,9273'],
            ['VIIRS', '0,8426±0,0006', '0,8425',
             '0,5838±0,0019', '0,8804±0,0022', '0,6997±0,0009'],
        ],
        col_widths=[22*mm, 32*mm, 24*mm, 32*mm, 32*mm, 30*mm],
        caption='Bảng 2. AUROC của XGBoost sau hiệu chuẩn trên 5 phép chia.')
    add_image(story, f'{CHARTS}/fig1_auroc_splits.png',
              caption='Hình 1. AUROC MODIS vs VIIRS theo 5 phép chia dữ liệu.')
    add_para(story,
        'Với VIIRS t+1, năm seed khác nhau (42, 123, 777, 2024, 31337) cho kết quả gần nhau '
        'với std chỉ 0,0019, do đó con số 0,5838 không phụ thuộc một lần khởi tạo đặc biệt. '
        'Các phép chia khác của VIIRS đạt 0,8426 ± 0,0006 ở IID, 0,8425 ở Temporal, 0,8804 '
        '± 0,0022 ở Nam→Trung và 0,6997 ± 0,0009 ở Trung+Nam→Bắc. Với MODIS, các giá trị '
        'tương ứng đều cao hơn đáng kể (0,9467; 0,9343; 0,9235; 0,9273). Sự chênh lệch '
        'giữa hai nguồn nhãn và giữa các vùng kiểm tra cho thấy <b>kết luận về độ tin cậy '
        'của mô hình phụ thuộc mạnh vào cả nguồn nhãn và vùng đánh giá</b>, phù hợp với '
        'giả thuyết H3.')

    add_heading_inline(story, '3.2. Ảnh hưởng khoảng dự báo t+1, t+3, t+7', H2)
    add_para(story,
        'Hình 2 trình bày AUROC của ba mô hình XGBoost, MLP và PhysMLP trên ba khoảng dự '
        'báo t+1, t+3 và t+7 (VIIRS, seed 42). XGBoost đạt khoảng 0,842 ở t+1, 0,828 ở t+3 '
        'và 0,821 ở t+7. MLP và PhysMLP có kết quả gần với XGBoost, cho thấy hiệu năng ba '
        'mô hình tương đương khi không chuyển miền.')
    add_image(story, f'{CHARTS}/fig2_horizons.png',
              caption='Hình 2. AUROC theo khoảng dự báo t+1/t+3/t+7 (3 mô hình, VIIRS).')
    add_para(story,
        'Điều đáng chú ý là <b>mức giảm từ t+1 đến t+7 chỉ khoảng 0,02</b>, nhỏ hơn nhiều '
        'so với mức giảm 0,26 khi chuyển từ Bắc sang Nam. Điều này gợi ý rằng, trong bộ dữ '
        'liệu hiện tại, vấn đề khó hơn không phải là dự báo xa hơn vài ngày trong cùng '
        'vùng, mà là đưa mô hình sang một vùng địa lý có điều kiện và quan hệ cháy khác '
        'với vùng đã học. Phát hiện này có ý nghĩa thực tiễn: nếu hệ thống cảnh báo chỉ '
        'quan tâm đến dự báo ngắn hạn (1–7 ngày) trong cùng vùng, thì khoảng dự báo không '
        'phải là điểm nghẽn chính — điểm nghẽn nằm ở khả năng chuyển miền.')

    add_heading_inline(story, '3.3. Tính nhất quán vật lý qua thí nghiệm phản thực', H2)
    add_para(story,
        'Thí nghiệm phản thực (counterfactual test) kiểm tra xem khi tăng một biến đầu vào '
        '(ví dụ nhiệt độ), xác suất cháy dự báo có tăng theo kỳ vọng hay không. Tỷ lệ vi '
        'phạm là phần trăm các trường hợp mô hình đi ngược kỳ vọng đơn điệu. Bảng 3 và '
        'Hình 3 trình bày kết quả cho ba mô hình XGBoost, MLP và PhysMLP.')
    add_table(story,
        header=['Mô hình', 'Nhiệt độ↑', 'Độ ẩm↑', 'Gió↑', 'Mưa↑'],
        rows=[
            ['XGBoost', '4,4%',  '5,5%',  '90,4%', '51,2%'],
            ['MLP',     '84,0%', '15,7%', '0,0%',  '34,8%'],
            ['PhysMLP', '82,9%', '9,9%',  '0,0%',  '32,7%'],
        ],
        col_widths=[26*mm, 30*mm, 28*mm, 24*mm, 24*mm],
        caption='Bảng 3. Tỷ lệ vi phạm quan hệ đơn điệu kỳ vọng.')
    add_image(story, f'{CHARTS}/fig3_physics_violation.png',
              caption='Hình 3. Tỷ lệ vi phạm 4 quan hệ đơn điệu của 3 mô hình.')
    add_para(story,
        'PhysMLP cải thiện rõ ràng quan hệ <i>gió tăng → cháy tăng</i> (từ 90,4% ở XGBoost '
        'xuống 0% ở cả MLP và PhysMLP) và quan hệ <i>độ ẩm tăng → cháy giảm</i> (5,5% → '
        '9,9%). Tuy nhiên, tỷ lệ vi phạm quan hệ <i>nhiệt độ</i> vẫn cao (82,9% ở PhysMLP), '
        'cho thấy ràng buộc vật lý chưa đủ mạnh hoặc biểu diễn hàm mất mát chưa phù hợp với '
        'biến này. <b>Kết luận quan trọng:</b> ràng buộc vật lý cần được đánh giá theo từng '
        'quan hệ, thay vì chỉ nói "có physics" là mô hình đã đúng hơn. Hơn nữa, PhysMLP '
        'không giải quyết được vấn đề khái quát không gian (AUROC Bắc→Nam vẫn thấp) — đây '
        'là bằng chứng thực nghiệm cho thấy <b>ràng buộc vật lý ≠ khái quát ngoài miền</b>.')

    add_heading_inline(story, '3.4. Chẩn đoán nguyên nhân suy giảm Bắc → Nam', H2)
    add_para(story,
        'Phép chia Bắc→Nam cho sụt giảm AUROC mạnh nhất (VIIRS: 0,8426 → 0,5838). Để tìm '
        'nguyên nhân, đề tài thực hiện bốn thí nghiệm chẩn đoán riêng biệt, mỗi thí nghiệm '
        'kiểm tra một cơ chế giải thích khác nhau.')
    add_para(story,
        '<b>(1) Dịch chuyển phân phối (distribution shift):</b> nhiệt độ 2 m trung bình '
        '24,85°C ở Bắc vs 26,40°C ở Nam (Cohen\'s d ≈ 0,445); độ ẩm tương đối 82,81% vs '
        '80,73% (d ≈ 0,209); tốc độ gió 3,66 vs 3,19 m/s (d ≈ 0,203); số ngày không mưa '
        '2,60 vs 4,57. Nhiều kiểm định phân phối (KS, Anderson–Darling) đều bác bỏ giả '
        'thuyết đồng nhất ở p &lt; 0,001 → ủng hộ <b>H1</b>. Tuy nhiên, khác biệt phân phối '
        'đầu vào chưa giải thích hết mức giảm AUROC: theo lý thuyết, AUROC là chỉ số '
        'invariant với prevalence và tương đối bền vững với dịch chuyển vừa phải.')
    add_image(story, f'{CHARTS}/fig4_conditional_curves.png',
              caption='Hình 4. Quan hệ P(cháy|biến thời tiết) ở hai miền Bắc và Nam cho 4 biến.')
    add_para(story,
        '<b>(2) Thay đổi quan hệ điều kiện (concept drift):</b> Hình 4 cho thấy các đường '
        'P(cháy|biến) của hai miền không trùng nhau. Cùng mức nhiệt độ 26°C, xác suất cháy '
        'quan sát được ở Nam cao hơn ở Bắc; cùng mức độ ẩm 80%, ý nghĩa đối với nguy cơ '
        'cháy cũng khác. Đây là nguyên nhân sâu xa — ngay cả khi hai miền có một số giá trị '
        'thời tiết giống nhau, ý nghĩa của những giá trị đó đối với nguy cơ cháy không '
        'nhất thiết giống nhau → ủng hộ <b>H2</b>. Đây là concept drift, không thể khắc phục '
        'chỉ bằng chuẩn hóa phân phối đầu vào.')
    add_image(story, f'{CHARTS}/fig5_prevalence_spatial.png',
              caption='Hình 5. (a) AUROC Bắc→Nam không đổi khi kiểm soát tỷ lệ cháy; (b) Moran\'s I.')
    add_para(story,
        '<b>(3) Kiểm soát tỷ lệ cháy (prevalence control):</b> AUROC test đầy đủ 0,5819; '
        'sau case-control 1:1 là 0,5821 ± 0,0017 — gần như không đổi → <b>bác bỏ prevalence</b> '
        'là nguyên nhân, vì AUROC là chỉ số invariant với base rate. Thí nghiệm thực nghiệm '
        'đã xác nhận tính chất này.', style=BODY_NOINDENT)
    add_para(story,
        '<b>(4) Tự tương quan không gian (spatial autocorrelation):</b> ở khoảng cách 10 km, '
        'xác suất ô lân cận có cháy = 0,610, cao hơn nhiều so với ngẫu nhiên 0,292; '
        'Moran\'s I = 0,186 ± 0,215; mức đồng thuận giảm dần theo khoảng cách → ủng hộ '
        '<b>H5</b>: IID được hưởng lợi từ sự tương đồng ô lân cận, Bắc→Nam loại bỏ lợi thế '
        'này, làm AUROC giảm về mức phản ánh đúng khả năng khái quát.', style=BODY_NOINDENT)
    add_para(story,
        '<b>(5) Thử nghiệm biến đại diện vị trí:</b> khi bổ sung vĩ độ/kinh độ liên tục vào '
        'XGBoost, AUROC Bắc→Nam tăng vọt 0,5819 → 0,8113 — mức tăng rất lớn cho thấy có '
        'tín hiệu vị trí. Nhưng khi thay tọa độ liên tục bằng 10 dải vĩ độ (binned) hoặc '
        'nhóm tọa độ thô, điểm số lại giảm xuống dưới mức gốc (0,5596; 0,5479). Phần tăng '
        'có được là do mô hình <b>ghi nhớ vị trí cụ thể</b>, không học cơ chế có thể chuyển '
        'sang vùng mới → ủng hộ <b>H4</b>: có tín hiệu địa lý chưa được biểu diễn đầy đủ '
        'bằng biến thời tiết, có thể bắt nguồn từ NDVI, lớp phủ đất, địa hình hoặc hoạt '
        'động con người.', style=BODY_NOINDENT)

    # ============================================================
    # PHẦN 4: BÀN LUẬN
    # ============================================================
    add_heading_inline(story, 'PHẦN 4. BÀN LUẬN', PART_TITLE)
    add_para(story,
        'Phần Bàn luận đối chiếu kết quả thực nghiệm với các công bố quốc tế về kiểm tra '
        'ngoài miền [11] và cross-validation không gian [12], phân tích vai trò và giới hạn '
        'của các biến đại diện vị trí cũng như ràng buộc vật lý, và nêu bật đóng góp mới '
        'của đề tài đối với bài toán cảnh báo cháy rừng diện rộng tại Việt Nam.',
        style=BODY_NOINDENT)
    add_spacer(story, 4)

    add_heading_inline(story, '4.1. Bản chất sụt giảm khi chuyển miền địa lý', H2)
    add_para(story,
        'Kết quả thực nghiệm ở Phần 3 cho thấy sụt giảm AUROC Bắc→Nam trên VIIRS '
        '(0,8426 → 0,5838) không thể giải thích bằng một nguyên nhân đơn lẻ. Bốn thí nghiệm '
        'chẩn đoán đã loại bỏ các cơ chế giải thích phổ biến và chỉ ra rằng sự sụt giảm có '
        'nguồn gốc kép: <b>(i) distribution shift</b> — phân phối thời tiết miền Nam khác '
        'miền Bắc (Cohen\'s d từ 0,2 đến 0,4); và <b>(ii) concept drift</b> — quan hệ '
        'P(cháy|biến) thay đổi giữa hai miền. Cơ chế thứ hai này là nguyên nhân sâu xa hơn, '
        'vì nó không thể được khắc phục chỉ bằng cách chuẩn hóa phân phối đầu vào.')
    add_para(story,
        'Kết quả này phù hợp với các công bố quốc tế về OOD generalization [11]: khi dữ '
        'liệu kiểm tra có phân phối khác với dữ liệu huấn luyện, mô hình có thể suy giảm '
        'hiệu năng mạnh, đặc biệt nếu quan hệ điều kiện thay đổi. Trong bối cảnh cháy rừng, '
        'sự thay đổi này có thể bắt nguồn từ các cơ chế sinh thái/khí hậu khác nhau giữa hai '
        'miền: miền Bắc có mùa đông lạnh và khô với đợt gió mùa đông biển; miền Nam chịu ảnh '
        'hưởng của gió Lào và mùa khô Tây Nguyên kéo dài; chế độ canh tác nương rẫy và việc '
        'đốt đồng xuyên tiết cũng khác biệt. Các biến thời tiết đơn thuần không thể đại diện '
        'đầy đủ cho những khác biệt này.')
    add_para(story,
        'Một phát hiện quan trọng khác là <b>tự tương quan không gian</b> (Moran\'s I ≈ '
        '0,186) — đây là cơ chế thứ ba làm cho đánh giá IID trở nên lạc quan. Khi chia IID, '
        'mô hình được hưởng lợi từ việc các ô lân cận trong train và test có nhãn tương tự; '
        'phép chia Bắc→Nam loại bỏ lợi thế này. Cơ chế này phù hợp với các khuyến nghị về '
        'spatial cross-validation [12]: nếu không có rào cản không gian, điểm số trên tập '
        'kiểm tra sẽ bị phóng đại, dẫn đến kết luận sai về khả năng triển khai thực tế. '
        'Cuối cùng, việc kiểm soát prevalence (case-control 1:1) không đưa AUROC trở lại — '
        'bác bỏ cơ chế giải thích phổ biến nhưng sai: tỷ lệ cháy khác nhau giữa hai miền. '
        'AUROC là chỉ số invariant với prevalence, và thí nghiệm thực nghiệm đã xác nhận '
        'tính chất này. Sự sụt giảm không phải do base rate, mà do cấu trúc quan hệ thay đổi.')

    add_heading_inline(story, '4.2. Vai trò và giới hạn của biến vị trí / ràng buộc vật lý', H2)
    add_para(story,
        'Khi thêm tọa độ liên tục (lat/lon) vào XGBoost, AUROC Bắc→Nam tăng vọt từ 0,58 lên '
        '0,81 — dễ dẫn đến kết luận sai "chỉ cần thêm vị trí là giải quyết được bài toán". '
        'Tuy nhiên, khi thay tọa độ liên tục bằng 10 dải vĩ độ (binned) hoặc nhóm tọa độ thô, '
        'điểm số không những không tăng mà còn giảm xuống dưới mức gốc (0,56; 0,55). Điều '
        'này cho thấy phần tăng AUROC có được là do mô hình <b>ghi nhớ vị trí cụ thể</b>, '
        'không phải học được một cơ chế có thể chuyển sang vùng mới.')
    add_para(story,
        'Phát hiện này phù hợp với khuyến nghị về <i>representational vs. mechanistic '
        'generalization</i>: một mô hình có thể đạt điểm cao nhờ khả năng biểu diễn (mã hóa '
        'vị trí cụ thể) nhưng vẫn thất bại khi gặp vùng chưa từng thấy, vì cơ chế thực sự '
        '(điều gì quyết định cháy) chưa được học. Trong thực tế triển khai, mô hình có tọa '
        'độ liên tục có thể hữu ích cho một vùng cụ thể, nhưng không thể được dùng làm hệ '
        'thống cảnh báo diện rộng cho các vùng chưa có dữ liệu huấn luyện.')
    add_para(story,
        'Về ràng buộc vật lý, kết quả PhysMLP cho thấy ràng buộc đơn điệu giúp kiểm soát hành '
        'vi của một số quan hệ (đặc biệt gió và độ ẩm), nhưng không giải quyết được vấn đề '
        'khái quát không gian. Điều này phù hợp với khuyến nghị trong [6]: physics-informed '
        'machine learning cải thiện tính nhất quán của mô hình trong miền đã biết, nhưng '
        'không phải "đũa thần" cho OOD generalization. <b>Kết luận thực tiễn: ràng buộc vật '
        'lý nên được dùng như một phép kiểm tra tính nhất quán, không phải như một giải pháp '
        'cho khái quát không gian.</b>')

    add_heading_inline(story, '4.3. Bốn đóng góp mới của đề tài', H2)
    add_callout_compact(story,
        '<b>(1) Quy trình đánh giá OOD không gian đa chiều</b> — 5 phép chia thay vì IID '
        'đơn lẻ, tách 3 câu hỏi về khái quát (trong miền, ngoài miền thời gian, ngoài miền '
        'không gian). <b>(2) Đối chiếu 2 nguồn nhãn độc lập</b> MODIS + VIIRS — phát hiện '
        'sụt giảm 0,842→0,584 trên VIIRS, không thấy trên MODIS. <b>(3) Phân tách nguyên '
        'nhân 4 lớp</b> — distribution shift, concept drift, prevalence, spatial '
        'autocorrelation; kết luận concept drift là cơ chế chính, bác bỏ prevalence. '
        '<b>(4) PhysMLP như phép kiểm tra</b> — ràng buộc vật lý ≠ khái quát ngoài miền.',
        color=ACCENT)
    add_para(story,
        '<b>Ý nghĩa thực tiễn cho bài toán cảnh báo cháy rừng diện rộng tại Việt Nam:</b> '
        '<b>(i)</b> các nghiên cứu trước báo cáo AUROC 0,9+ có thể đã đánh giá quá lạc '
        'quan do chia IID — kết luận triển khai dựa trên con số này cần được xem xét lại '
        'bằng quy trình kiểm tra ngoài miền; <b>(ii)</b> triển khai hệ thống cho vùng mới '
        'không nên chỉ dựa vào mô hình huấn luyện ở vùng khác — cần có giai đoạn hiệu '
        'chỉnh bằng dữ liệu vùng mục tiêu và cảnh báo khi đầu vào ngoài miền đã học; '
        '<b>(iii)</b> cần tích hợp thông tin vùng vào mô hình theo cách có ý nghĩa cơ học '
        '(lớp phủ đất, NDVI, đặc điểm canh tác) thay vì chỉ dùng tọa độ liên tục — phát '
        'hiện này có thể mở rộng cho các hệ thống dự báo khác như lũ lụt, sạt lở, nơi cũng '
        'có vấn đề khái quát ngoài miền.')

    # ============================================================
    # PHẦN 5: KẾT LUẬN, HẠN CHẾ, HƯỚNG PHÁT TRIỂN
    # ============================================================
    add_heading_inline(story, 'PHẦN 5. KẾT LUẬN, HẠN CHẾ VÀ HƯỚNG PHÁT TRIỂN', PART_TITLE)
    add_spacer(story, 4)

    add_heading_inline(story, '5.1. Kết luận', H2)
    add_para(story,
        'Đề tài đã trả lời ba câu hỏi nghiên cứu đặt ra ở Phần 1 bằng một quy trình đánh giá '
        'đa chiều trên 598.143 quan sát ô–ngày, kết hợp năm phép chia dữ liệu và hai nguồn '
        'nhãn độc lập. Bốn kết luận chính rút ra từ kết quả thực nghiệm:')
    add_callout_compact(story,
        '<b>K1.</b> Khoảng dự báo không phải vấn đề lớn: XGBoost giảm chỉ ≈0,02 khi kéo '
        'dài từ t+1 đến t+7 trong cùng miền. <b>K2.</b> Chuyển miền địa lý khó hơn đáng '
        'kể: VIIRS sụt giảm từ 0,8426 (IID) xuống 0,5838 ± 0,0019 (Bắc→Nam), gần với mức '
        'ngẫu nhiên. <b>K3.</b> Sự sụt giảm không do prevalence: case-control 1:1 không '
        'đưa AUROC trở lại; nguyên nhân là distribution shift + concept drift + spatial '
        'autocorrelation. <b>K4.</b> Ràng buộc vật lý (PhysMLP) cải thiện một số quan hệ '
        'đơn điệu (gió, độ ẩm) nhưng <b>không</b> giải quyết được khái quát ngoài miền.',
        color=SEM_SUCCESS)
    add_para(story,
        'Điểm quan trọng nhất không phải là một con số AUROC cao, mà là nhận ra rằng '
        '<b>điểm số có thể thay đổi rất mạnh khi cách kiểm tra thay đổi</b>. Đối với bài '
        'toán cảnh báo cháy rừng diện rộng, độ tin cậy của mô hình phải được xem cùng với '
        'miền dữ liệu mà mô hình đang được áp dụng — không có mô hình duy nhất nào "tốt" '
        'cho mọi vùng. Nếu triển khai thực tế, hệ thống nên có cơ chế nhận biết khi dữ '
        'liệu đầu vào khác xa miền đã học, thay vì chỉ trả về một xác suất cháy.')

    add_heading_inline(story, '5.2. Hạn chế', H2)
    add_para(story,
        'Đề tài có ba hạn chế chính cần được công bố rõ ràng. <b>Hạn chế 1:</b> Bộ biến '
        'đầu vào chưa đầy đủ: chưa có NDVI, lớp phủ đất, độ cao địa hình và các biến về '
        'hoạt động của con người, nên không thể xác định riêng yếu tố nào tạo ra tín hiệu '
        'địa lý chưa được mô hình hóa. <b>Hạn chế 2:</b> MODIS và VIIRS đều có giới hạn '
        'trong việc phát hiện cháy (đặc biệt là cháy quy mô nhỏ, dưới tán rừng hoặc có mây '
        'che phủ); Jaccard ≈ 0,106 giữa hai nguồn là bằng chứng cho vấn đề này. <b>Hạn chế '
        '3:</b> Các thí nghiệm t+3 và t+7 hiện mới dùng seed 42, chưa có std — đây là kết '
        'quả khảo sát ban đầu về ảnh hưởng của khoảng dự báo, chưa phải kết luận có độ ổn '
        'định như thí nghiệm t+1 (5 seed).')

    add_heading_inline(story, '5.3. Hướng phát triển', H2)
    add_para(story,
        'Từ các hạn chế trên, ba hướng phát triển được đề xuất cho giai đoạn tiếp theo. '
        '<b>(i)</b> Bổ sung các biến môi trường và không gian từ nguồn độc lập: NDVI (MODIS '
        'Vegetation Indices), lớp phủ đất (ESA WorldCover), độ cao địa hình (SRTM), và '
        'các biến đại diện cho hoạt động của con người. Sau đó đánh giá lại bằng cùng năm '
        'phép chia giữ nguyên vùng ngoài tập huấn luyện, để xem tín hiệu địa lý còn đáng '
        'kể hay không. <b>(ii)</b> Tiếp tục kiểm tra mô hình trên các khu vực có phân phối '
        'dữ liệu khác: ví dụ huấn luyện trên Việt Nam và kiểm tra trên Lào, Campuchia; hoặc '
        'trên miền Bắc Việt Nam giai đoạn 2018–2020 và kiểm tra giai đoạn 2024–2025. Mục '
        'tiêu là xem các kết luận về concept drift có lặp lại ở quy mô quốc tế hay không. '
        '<b>(iii)</b> Xây dựng một lớp cảnh báo độ tin cậy (OOD detection) cho hệ thống: '
        'dựa trên khoảng cách Mahalanobis hoặc độ bất thường của phân phối đầu vào, hệ '
        'thống có thể báo "dữ liệu hiện tại đang ngoài miền đã học, kết quả có thể không '
        'đáng tin", thay vì chỉ trả về một xác suất cháy. Đây là hướng triển khai thực tế '
        'nhất cho một hệ thống cảnh báo diện rộng có trách nhiệm.')

    # ============================================================
    # TÀI LIỆU THAM KHẢO
    # ============================================================
    add_heading_inline(story, 'TÀI LIỆU THAM KHẢO', PART_TITLE)
    add_para(story,
        'Danh mục tài liệu tham khảo theo chuẩn IEEE, đánh số theo thứ tự xuất hiện trong '
        'bài. Mỗi tài liệu kèm liên kết DOI hoặc URL bấm được.', style=BODY_NOINDENT)
    add_spacer(story, 4)

    refs = [
        ('[1]', 'Chen, T., &amp; Guestrin, C. (2016). XGBoost: A Scalable Tree Boosting System. '
                '<i>KDD</i>, 785–794. ', 'https://doi.org/10.1145/2939672.2939785'),
        ('[2]', 'Giglio, L., Schroeder, W., &amp; Justice, C. O. (2016). The Collection 6 '
                'MODIS active fire detection algorithm and fire products. <i>RSE</i>, 178, 31–41. ',
                'https://doi.org/10.1016/j.rse.2016.02.054'),
        ('[3]', 'Schroeder, W., Oliva, P., Giglio, L., &amp; Csiszar, I. A. (2014). The New '
                'VIIRS 375 m active fire detection data product. <i>RSE</i>, 143, 85–96. ',
                'https://doi.org/10.1016/j.rse.2013.12.028'),
        ('[4]', 'Justice, C. O., et al. (2002). The MODIS fire products. <i>RSE</i>, 83(1–2), 244–262. ',
                'https://doi.org/10.1016/S0034-4257(02)00076-7'),
        ('[5]', 'NASA Langley Research Center. <i>NASA POWER Project</i>. ',
                'https://power.larc.nasa.gov/'),
        ('[6]', 'Karniadakis, G. E., et al. (2021). Physics-informed machine learning. '
                '<i>Nature Reviews Physics</i>, 3, 422–440. ',
                'https://doi.org/10.1038/s42254-021-00314-5'),
        ('[7]', 'Niculescu-Mizil, A., &amp; Caruana, R. (2005). Predicting good probabilities '
                'with supervised learning. <i>ICML</i>, 625–632. ',
                'https://doi.org/10.1145/1102351.1102430'),
        ('[8]', 'Breiman, L. (2001). Random Forests. <i>Machine Learning</i>, 45(1), 5–32. ',
                'https://doi.org/10.1023/A:1010933404324'),
        ('[9]', 'Friedman, J. H. (2001). Greedy function approximation: A gradient boosting '
                'machine. <i>Annals of Statistics</i>, 29(5), 1189–1232. ',
                'https://doi.org/10.1214/aos/1013203451'),
        ('[10]', 'Anselin, L. (1995). Local Indicators of Spatial Association — LISA. '
                 '<i>Geographical Analysis</i>, 27(2), 93–115. ',
                 'https://doi.org/10.1111/j.1538-4632.1995.tb00338.x'),
        ('[11]', 'Shen, Z., et al. (2021). Towards Out-of-Distribution Generalization: A Survey. '
                 '<i>arXiv:2108.13624</i>. ', 'https://arxiv.org/abs/2108.13624'),
        ('[12]', 'Roberts, D. R., et al. (2017). Cross-validation strategies for data with '
                 'temporal, spatial, hierarchical, or phylogenetic structure. '
                 '<i>Ecography</i>, 40(8), 913–929. ',
                 'https://doi.org/10.1111/ecog.02881'),
        ('[13]', 'Fawcett, T. (2006). An introduction to ROC analysis. '
                 '<i>Pattern Recognition Letters</i>, 27(8), 861–874. ',
                 'https://doi.org/10.1016/j.patrec.2005.10.010'),
        ('[14]', 'Hastie, T., Tibshirani, R., &amp; Friedman, J. (2009). <i>The Elements of '
                 'Statistical Learning</i> (2nd ed.). Springer. ',
                 'https://doi.org/10.1007/978-0-387-84858-7'),
    ]
    for num, body_text, url in refs:
        html = (f'<b>{num}</b> {body_text}'
                f'<a href="{url}" color="#93761f"><u>{url}</u></a>')
        story.append(Paragraph(html, REF_ITEM))
    add_spacer(story, 4)
    add_para(story,
        '<i>Nguồn dữ liệu:</i> NASA POWER [5]; MODIS Active Fire [2], [4]; VIIRS 375 m [3]. '
        'Mã nguồn và kết quả thực nghiệm lưu trong dự án v8.6 Phase A.',
        style=KEYWORDS)

    return story


def main():
    out_path = '/home/z/my-project/work/body_compact.pdf'
    doc = SimpleDocTemplate(
        out_path,
        pagesize=A4,
        leftMargin=LEFT_MARGIN,
        rightMargin=RIGHT_MARGIN,
        topMargin=TOP_MARGIN + 4*mm,
        bottomMargin=BOT_MARGIN + 4*mm,
        title='Đánh giá độ tin cậy và khả năng khái quát không gian của mô hình dự báo cháy rừng',
        author='Hoàng Bảo Lâm',
        subject='Báo cáo KHKT — Dự báo cháy rừng dựa trên dữ liệu vệ tinh',
        creator='Z.ai',
    )
    story = build_story()
    doc.build(story, onFirstPage=draw_header_footer, onLaterPages=draw_header_footer)
    print(f'✓ Compact body PDF generated: {out_path}')
    print(f'  Size: {os.path.getsize(out_path)/1024:.1f} KB')

if __name__ == '__main__':
    main()
