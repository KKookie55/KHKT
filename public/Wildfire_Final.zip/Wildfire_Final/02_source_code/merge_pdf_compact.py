"""
Merge cover.pdf + body_compact.pdf → final compact report PDF (≤ 15 pages).
"""
import os
from pypdf import PdfWriter, PdfReader
from pypdf.generic import RectangleObject

COVER = '/home/z/my-project/work/cover.pdf'
BODY  = '/home/z/my-project/work/body_compact.pdf'
OUT   = '/home/z/my-project/download/Bao_cao_KHKT_Du_bao_chay_rung_V9_Compact.pdf'

A4_W = 595.276
A4_H = 841.890

writer = PdfWriter()

# Cover — normalize page size to A4 exactly
cov = PdfReader(COVER)
for p in cov.pages:
    p.mediabox = RectangleObject([0, 0, A4_W, A4_H])
    p.cropbox  = RectangleObject([0, 0, A4_W, A4_H])
    p.bleedbox = RectangleObject([0, 0, A4_W, A4_H])
    p.trimbox  = RectangleObject([0, 0, A4_W, A4_H])
    p.artbox   = RectangleObject([0, 0, A4_W, A4_H])
    writer.add_page(p)

# Body
bod = PdfReader(BODY)
for p in bod.pages:
    writer.add_page(p)

writer.add_metadata({
    '/Title': 'Đánh giá độ tin cậy và khả năng khái quát không gian của mô hình dự báo cháy rừng (Bản compact)',
    '/Author': 'Hoàng Bảo Lâm',
    '/Subject': 'Báo cáo KHKT — Dự báo cháy rừng dựa trên dữ liệu vệ tinh (MODIS, VIIRS, NASA POWER)',
    '/Creator': 'Z.ai',
    '/Keywords': 'cháy rừng; MODIS; VIIRS; XGBoost; kiểm tra ngoài miền; khái quát không gian; PhysMLP; Moran\'s I',
})

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'wb') as f:
    writer.write(f)

size_kb = os.path.getsize(OUT) / 1024
total_pages = len(cov.pages) + len(bod.pages)
print(f'✓ Merged final compact PDF: {OUT}')
print(f'  Pages: {total_pages} (cover={len(cov.pages)}, body={len(bod.pages)})')
print(f'  Size:  {size_kb:.1f} KB ({size_kb/1024:.2f} MB)')

# Verify page count constraint
assert total_pages <= 15, f'FAIL: {total_pages} > 15 pages'
print(f'  ✓ Page count constraint satisfied: {total_pages} ≤ 15')
