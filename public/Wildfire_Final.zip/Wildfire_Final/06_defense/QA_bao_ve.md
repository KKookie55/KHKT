# Phần bảo vệ — 8 câu hỏi chính

## Câu 1: Điểm mới thực sự của nghiên cứu là gì?

Điểm mới không phải là dùng XGBoost để dự báo cháy — điều này đã được làm trước.
Điểm mới là **phát hiện rằng mô hình đạt AUROC 0,95 trên phép chia IID nhưng sụt giảm
xuống 0,58 khi chuyển từ Bắc sang Nam**, và việc **phân tách cơ chế** gây sụt giảm
qua 4 thí nghiệm chẩn đoán (distribution shift, concept drift, prevalence control,
spatial autocorrelation). Kết quả cho rằng tọa độ liên tục phục hồi AUROC (0,58→0,81)
nhưng phân nhóm tọa độ không — gợi ý mô hình cần gradient địa lý liên tục chứ không
phải nhãn vùng.

## Câu 2: Tại sao chọn XGBoost thay vì phương pháp đơn giản hơn?

XGBoost được chọn vì 3 lý do: (1) ổn định với dữ liệu dạng bảng, (2) dễ thiết lập
thí nghiệm thêm/bớt biến, (3) cho kết quả gần với MLP và PhysMLP. 5 mô hình đều được
thử (LogReg, RF, XGBoost, MLP, PhysMLP) — XGBoost là mô hình đại diện cho chẩn đoán,
không phải mô hình duy nhất.

## Câu 3: Vì sao hiệu năng giảm khi đánh giá trên vùng địa lý mới?

Kết quả đo được: phân phối thời tiết khác (Cohen's d 0,2–0,4) và đường P(cháy|biến)
khác giữa hai miền. Thí nghiệm case-control 1:1 cho AUROC không đổi — phù hợp với
tính chất AUROC không phụ thuộc prevalence. Còn lại: distribution shift + concept drift
+ spatial autocorrelation. Nhưng chưa định lượng riêng mức đóng góp của từng cơ chế.

## Câu 4: Làm sao biết mô hình đang học tín hiệu khí tượng thay vì ghi nhớ vị trí?

Trong phép chia Bắc→Nam, ô test (miền Nam) chưa từng xuất hiện trong train. Nếu
lat/lon phục hồi AUROC, mô hình không thể đang ghi nhớ từng ô cụ thể. Điều lat/lon
cho phép là nội suy một hàm địa lý liên tục. Phiên bản phân nhóm (10 dải vĩ độ)
thất bại — cho thấy mô hình cần giá trị liên tục, không phải nhãn vùng. Tuy nhiên,
chưa xác định được hàm địa lý đó mã hóa biến môi trường nào cụ thể.

## Câu 5: MODIS và VIIRS bất đồng thì định nghĩa nhãn cháy như thế nào?

MODIS là nhãn chính, VIIRS là kiểm chứng độc lập. Jaccard ≈ 0,106 — mức chồng
lấn thấp. Tôi không coi nguồn nào là ground truth tuyệt đối. Cả hai đều có giới hạn
phát hiện (cháy nhỏ, dưới tán, mây che). Báo cáo trình bày kết quả trên cả hai nguồn
để thấy kết luận có thay đổi hay không.

## Câu 6: AUROC cao có đồng nghĩa với dự báo chính xác không?

Không. AUROC đo khả năng xếp hạng, không đo độ chính xác xác suất. Đó là lý do
tôi báo cáo thêm Brier score và ECE sau hiệu chuẩn isotonic. AUROC 0,95 trên IID
có thể lạc quan vì chia ngẫu nhiên — khi chia theo không gian, AUROC giảm mạnh.

## Câu 7: Nếu mô hình chưa đủ tốt để vận hành, giá trị khoa học nằm ở đâu?

Giá trị nằm ở 3 điểm: (1) phát hiện rằng đánh giá IID truyền thống có thể lạc quan,
(2) phân tách cơ chế suy giảm khi chuyển vùng, (3) chỉ ra rằng biến môi trường
(lớp phủ đất) có thể là hướng cải thiện. Đây là nghiên cứu phương pháp luận,
không phải hệ thống cảnh báo sẵn sàng triển khai.

## Câu 8: Bạn trực tiếp thực hiện những phần nào?

Tôi thực hiện: thu thập dữ liệu (NASA POWER, MODIS, VIIRS), xây dựng panel ô–ngày,
code Python cho 5 mô hình + 5 phép chia, phân tích thống kê (AUROC, Moran's I,
Cohen's d, case-control), tạo biểu đồ, viết báo cáo. Giới hạn chưa giải quyết:
thiếu biến môi trường (NDVI, lớp phủ đất), t+3/t+7 mới 1 seed, Moran's I chưa
có permutation test.

---

## Lưu ý khi trả lời
- Phân biệt "đã quan sát được" với "có thể giải thích" và "chưa xác định"
- Không dùng kết quả synthetic để xác nhận kết luận từ dữ liệu thật
- Nếu không biết câu trả lời, nói thẳng: "tôi chưa kiểm tra điều đó"
